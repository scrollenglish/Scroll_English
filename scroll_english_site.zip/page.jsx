import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Instagram, Send } from "lucide-react";
import Image from "next/image";

export default function ScrollEnglishLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-purple-100 p-6 flex flex-col items-center">
      <h1 className="text-4xl md:text-6xl font-bold text-purple-800 mb-4 text-center">
        ENGLISH FOR SCROLLERS
      </h1>
      <p className="text-lg md:text-xl text-center max-w-2xl text-purple-700 mb-6">
        Capisci i Reels? No? Vieni. First 30 minutes only 5€ ☕ Learn real English for TikTok, YouTube, Netflix, and your love life 😏
      </p>

      <Image
        src="/scroll_english_qr.png"
        alt="QR Code to join Telegram"
        width={200}
        height={200}
        className="mb-4"
      />
      <p className="text-md text-purple-800 mb-4">Scan to join our Telegram: @scroll_english</p>

      <Card className="w-full max-w-md bg-white shadow-xl">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold text-purple-700">📚 Offers</h2>
          <ul className="list-disc pl-6 text-purple-600">
            <li>🎓 Students: 12€/hour</li>
            <li>🔥 First session (30 min): 5€</li>
            <li>🧠 Exam sessions (90 mins): 17€</li>
            <li>🌟 Regulars & packs: from 10€/hour</li>
          </ul>
        </CardContent>
      </Card>

      <Button className="mt-6 text-white bg-purple-700 hover:bg-purple-800 text-lg px-6 py-3 rounded-full flex items-center gap-2">
        <Send size={20} />
        <a href="https://t.me/scroll_english" target="_blank">Join on Telegram</a>
      </Button>

      <p className="text-sm text-purple-500 mt-4">Classes in cafés & bars across Turin. Come speak English where you sip espresso!</p>
    </div>
  );
}
